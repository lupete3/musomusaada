<!-- resources/views/livewire/global-credit-dashboard.blade.php -->

<div class="container mt-4">
    <!-- Statistiques des crédits -->
    <div class="row g-2 mb-4">
        <div class="col-md-2 ">
            <div class="card card-border-shadow border-start-primary">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Crédits totaux</h6>
                        <h5 class="mb-0"><?php echo e($totalCredits); ?></h5>
                    </div>
                    <div class="avatar bg-primary text-white rounded-circle shadow">
                        <i class="bx bx-money fs-4 m-2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2 ">
            <div class="card card-border-shadow border-start-success">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">En cours</h6>
                        <h5 class="mb-0"><?php echo e($creditsInProgress); ?></h5>
                    </div>
                    <div class="avatar bg-success text-white rounded-circle shadow">
                        <i class="bx bx-hourglass fs-4 m-2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-2 ">
            <div class="card card-border-shadow border-start-danger">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">En retard</h6>
                        <h5 class="mb-0"><?php echo e($overdueCreditsCount); ?></h5>
                    </div>
                    <div class="avatar bg-danger text-white rounded-circle shadow">
                        <i class="bx bx-error fs-4 m-2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 ">
            <div class="card card-border-shadow border-start-warning">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Pénalités cumulées USD</h6>
                        <h5 class="mb-0"><?php echo e(number_format($totalPenalties['USD'], 2)); ?></h5>
                    </div>
                    <div class="avatar bg-warning text-white rounded-circle shadow">
                        <i class="bx bx-dollar fs-4 m-2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3 ">
            <div class="card card-border-shadow border-start-info">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-muted mb-1">Pénalités cumulées CDF</h6>
                        <h5 class="mb-0"><?php echo e(number_format($totalPenalties['CDF'], 2)); ?></h5>
                    </div>
                    <div class="avatar bg-info text-white rounded-circle shadow">
                        <i class="bx bx-wallet fs-4 m-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Section Caisse Centrale & Échéances en retard -->
    <div class="row">
        <div class="col-md-7 mb-4">
            <div class="row">
                <div class="col-md-12">
                    <div class="card h-100">
                        <div class="card-header bg-label-primary fw-bold">
                            Soldes Caisse Centrale
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush" style="font-size: 24px">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cashRegisters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <?php echo e($cr->currency); ?>

                                        <span class="badge bg-primary">
                                            <?php echo e(number_format($cr->balance, 2)); ?> <?php echo e($cr->currency); ?>

                                        </span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 mt-4">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('membership-card-stats', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1084256907-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>

        <div class="col-md-5 mb-4">
            <div class="card h-100">
                <div class="card-header bg-label-danger fw-bold">
                    Échéances en retard
                </div>
                <div class="card-body p-0">
                    <!--[if BLOCK]><![endif]--><?php if($overdueCredits->isEmpty()): ?>
                        <div class="p-3">Aucune échéance en retard.</div>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $overdueCredits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo e($r->credit->user->code. ' '. $r->credit->user->name); ?></strong><br>
                                        <small class="text-muted">Montant : <?php echo e($r->total_due.' '.$r->credit->currency); ?></small>
                                    </div>
                                    <span class="badge bg-danger">
                                        <?php echo e(\Carbon\Carbon::parse($r->due_date)->format('d/m/Y')); ?>

                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="mt-3">
                        <?php echo e($overdueCredits->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Liste des crédits -->
    <div class="card">
        <div class="card-header bg-label-secondary fw-bold">
            Liste des crédits en cours
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="table-light">
                        <tr>
                            <th>Membre</th>
                            <th>Devise</th>
                            <th>Montant</th>
                            <th>Taux</th>
                            <th>Échéances</th>
                            <th>Date de début</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($credit->user->name.' '.$credit->user->postnom); ?></td>
                                <td><?php echo e($credit->currency); ?></td>
                                <td><?php echo e(number_format($credit->amount, 2)); ?></td>
                                <td><?php echo e($credit->interest_rate); ?>%</td>
                                <td><?php echo e($credit->installments); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($credit->start_date)->format('d/m/Y')); ?></td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($credit->is_paid): ?>
                                        <span class="badge bg-success">Remboursé</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">En cours</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                                <td>
                                    <a href="<?php echo e(route('schedule.generate', ['creditId' => $credit->id])); ?>" target="_blank" class="btn btn-sm btn-secondary">
                                        Imprimer le plan
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Aucun crédit trouvé.</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <?php echo e($credits->links()); ?>

            </div>
        </div>
    </div>

    

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
    document.addEventListener('livewire:load', function () {


        // Crédits par mois
        new ApexCharts(document.querySelector("#creditsByMonthChart"), {
            chart: {
                type: 'bar',
                height: 300
            },
            series: [{
                name: 'Crédits',
                data: <?php echo json_encode($creditsCounts, 15, 512) ?>
            }],
            xaxis: {
                categories: <?php echo json_encode($creditsMonths, 15, 512) ?>
            },
            colors: ['#0d6efd']
        }).render();

        // Crédits par devise
        new ApexCharts(document.querySelector("#creditsByCurrencyChart"), {
            chart: {
                type: 'pie',
                height: 300
            },
            series: <?php echo json_encode($currencyCounts, 15, 512) ?>,
            labels: <?php echo json_encode($currencyLabels, 15, 512) ?>,
            colors: ['#198754', '#ffc107', '#dc3545', '#0dcaf0']
        }).render();

        // Remboursements par mois
        new ApexCharts(document.querySelector("#repaymentsByMonthChart"), {
            chart: {
                type: 'line',
                height: 300
            },
            series: [{
                name: 'Montant remboursé',
                data: <?php echo json_encode($repaymentAmounts, 15, 512) ?>
            }],
            xaxis: {
                categories: <?php echo json_encode($repaymentMonths, 15, 512) ?>
            },
            colors: ['#fd7e14']
        }).render();
    });
</script>
</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/admin/global-credit-dashboard.blade.php ENDPATH**/ ?>
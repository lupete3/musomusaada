<div>
    <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-3 me-xl-2" wire:poll.30s>
        <a class="nav-link dropdown-toggle hide-arrow" href="#" data-bs-toggle="dropdown">
            <i class="bx bx-bell bx-sm"></i>
            <!--[if BLOCK]><![endif]--><?php if($unreadCount > 0): ?>
                <span class="badge bg-danger rounded-pill"><?php echo e($unreadCount); ?></span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </a>

        <ul class="dropdown-menu dropdown-menu-end p-0">
            <li class="dropdown-menu-header border-bottom">
                <div class="dropdown-header d-flex align-items-center py-3">
                    <h6 class="mb-0 me-auto">Notifications</h6>
                    <div class="d-flex align-items-center h6 mb-0">
                        <!--[if BLOCK]><![endif]--><?php if($unreadCount > 0): ?>
                            <span class="badge bg-label-primary me-2"><?php echo e($unreadCount); ?> New</span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <a href="#" class="dropdown-notifications-all p-2" wire:click.prevent="markAllAsRead"
                            data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Tout marquer comme lu">
                            <i class="icon-base bx bx-envelope-open text-heading"></i>
                        </a>
                    </div>
                </div>
            </li>

            <li class="dropdown-notifications-list scrollable-container">
                <ul class="list-group list-group-flush">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li
                            class="list-group-item list-group-item-action dropdown-notifications-item <?php if($notification->read): ?> marked-as-read <?php endif; ?>">
                            <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                    <div class="avatar avatar-initial rounded-circle bg-label-info">
                                        <i class="bx bx-bell m-2"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="small mb-0"><?php echo e($notification->title); ?></h6>
                                    <small class="mb-1 d-block text-body"><?php echo e($notification->message); ?></small>
                                    <small
                                        class="text-body-secondary"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                                </div>
                                <div class="flex-shrink-0 dropdown-notifications-actions">
                                    <!--[if BLOCK]><![endif]--><?php if(!$notification->read): ?>
                                        <button wire:click.prevent="markAsRead(<?php echo e($notification->id); ?>)"
                                            class="dropdown-notifications-read">
                                            <span class="badge badge-dot"></span>
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <button wire:click.prevent="markAsRead(<?php echo e($notification->id); ?>)"
                                        class="dropdown-notifications-archive">
                                        <span class="icon-base bx bx-x"></span>
                                    </button>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="list-group-item text-center text-muted">Aucune notification</li>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </ul>
            </li>
        </ul>
    </li>

</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/notification-navbar.blade.php ENDPATH**/ ?>
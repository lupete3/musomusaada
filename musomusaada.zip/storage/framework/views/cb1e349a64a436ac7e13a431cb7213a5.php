<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
        <a wire:navigate href="<?php echo e(route('dashboard')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo ">
                <img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" width="50px" alt="" class="mr-2">
            </span>
            <?php echo e(config( 'app.name', 'Laravel')); ?>


        </a>

        <a wire:navigate href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>

    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <!-- Dashboard -->
        <li class="menu-item <?php if(request()->routeIs('dashboard')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-grid-alt"></i> <!-- Tableau de bord -->
                <div data-i18n="Analytics">Tableau de bord</div>
            </a>
        </li>

        <!-- Liens Comptable -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-caisse-centrale')): ?>
        <li class="menu-item <?php if(request()->routeIs('cash.register')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('cash.register')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-wallet"></i> <!-- Caisse centrale -->
                <div data-i18n="Analytics">Caisse Centrale</div>
            </a>
        </li>
        <?php endif; ?>

        <!-- Liens Comptable -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('depot-compte-membre')): ?>
            <li class="menu-item <?php if(request()->routeIs('agent.cloture')): ?> active <?php endif; ?>">
                <a wire:navigate href="<?php echo e(route('agent.cloture')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-money"></i> <!-- Meilleure icône pour la caisse -->
                    <div data-i18n="Analytics">Clôture Caisse Agent</div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('effectuer-virement')): ?>
            <li class="menu-item <?php if(request()->routeIs('transfert.ajouter')): ?> active <?php endif; ?>">
                <a wire:navigate href="<?php echo e(route('transfert.ajouter')); ?>" class="menu-link">
                    <i class="menu-icon tf-icons bx bx-transfer"></i> <!-- Icône spécifique pour transfert -->
                    <div data-i18n="Analytics">Transfert Compte</div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-caisse-agent')): ?>
        <li class="menu-item <?php if(request()->routeIs('agent.dashboard')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('agent.dashboard')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-briefcase-alt-2"></i> <!-- Caisse agents -->
                <div data-i18n="Analytics">Caisse Agents</div>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-rapport-credit')): ?>
            <li class="menu-item <?php if(request()->routeIs('report.credit.overview','report.credit.followup','credit.grant')): ?> 
                active <?php endif; ?>" wire:ignore.self>
                <a class="menu-link menu-toggle">
                    <i class="menu-icon tf-icons bx bx-credit-card"></i>
                    <div data-i18n="Misc">Crédits</div>
                </a>
                <ul class="menu-sub">
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter-credit', App\Models\User::class)): ?>
                        <li class="menu-item">
                            <a wire:navigate href="<?php echo e(route('credit.grant')); ?>" class="menu-link">
                                <i class="menu-icon tf-icons bx bx-plus-circle"></i> <!-- Plus pour ajouter -->
                                <div data-i18n="Analytics">Octroyer un Crédit</div>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-credit')): ?>
                    <li class="menu-item <?php if(request()->routeIs('repayments.manage')): ?> active <?php endif; ?>">
                        <a wire:navigate href="<?php echo e(route('repayments.manage')); ?>" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-refresh"></i> <!-- Remboursements -->
                            <div data-i18n="Analytics">Gérer les Remboursements</div>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter-transfert-caisse', App\Models\User::class)): ?>
        <li class="menu-item <?php if(request()->routeIs('transfer.to.central')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('transfer.to.central')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-transfer"></i> <!-- Virement -->
                <div data-i18n="Analytics">Virement Caisse Centrale</div>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-client', App\Models\User::class)): ?>
        <li
            class="menu-item <?php if(request()->routeIs('member.register','member.details','receipt.generate')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('member.register')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-group"></i> <!-- Membres -->
                <div data-i18n="Analytics">Gestion des membres</div>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-carnet', App\Models\User::class)): ?>
        <!-- Vente de cartes membres -->
        <li class="menu-item <?php if(request()->routeIs('members.sell-card')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('members.sell-card')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-id-card"></i> <!-- Icône de carte membre -->
                <div data-i18n="Analytics">Vente Cartes Membres</div>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-simulation-credit', App\Models\User::class)): ?>
        <!-- Simulation de crédit -->
        <li class="menu-item <?php if(request()->routeIs('repayments.simulation')): ?> active <?php endif; ?>">
            <a wire:navigate href="<?php echo e(route('repayments.simulation')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-calculator"></i> <!-- Icône de calculateur -->
                <div data-i18n="Analytics">Simulation Crédit</div>
            </a>
        </li>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-rapport-credit')): ?>
        <li class="menu-item <?php if(request()->routeIs('rapports.clients','rapports.carnets')): ?> 
            active <?php endif; ?>" wire:ignore.self>
            <a class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-file"></i> <!-- Icône générale pour rapports -->
                <div data-i18n="Misc">Rapports</div>
            </a>
            <ul class="menu-sub">
                
                <li class="menu-item <?php if(request()->routeIs('rapports.clients')): ?> active <?php endif; ?>">
                    <a wire:navigate href="<?php echo e(route('rapports.clients')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-user"></i> <!-- Utilisateurs -->
                        <div data-i18n="Analytics">Rapports Clients</div>
                    </a>
                </li>
                
                <li class="menu-item <?php if(request()->routeIs('member.accounts')): ?> active <?php endif; ?>">
                    <a wire:navigate href="<?php echo e(route('member.accounts')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-user"></i> <!-- Utilisateurs -->
                        <div data-i18n="Analytics">Comptes Clients</div>
                    </a>
                </li>
                
                <li class="menu-item <?php if(request()->routeIs('rapports.carnets')): ?> active <?php endif; ?>">
                    <a wire:navigate href="<?php echo e(route('rapports.carnets')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-book"></i> <!-- Livre/carnet -->
                        <div data-i18n="Analytics">Rapports Carnets</div>
                    </a>
                </li>
                
                <li class="menu-item">
                    <a wire:navigate href="<?php echo e(route('report.credit.overview')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-time"></i> <!-- Horloge pour "en cours" -->
                        <div data-i18n="Analytics">Rapport Crédits En Cours</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a wire:navigate href="<?php echo e(route('report.credit.followup')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart"></i> <!-- Graphique pour rapports -->
                        <div data-i18n="Analytics">Rapport Total Crédits</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a wire:navigate href="<?php echo e(route('rapports.transactions')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart"></i> <!-- Graphique pour rapports -->
                        <div data-i18n="Analytics">Rapport Transactions</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a wire:navigate href="<?php echo e(route('report.repayments')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart"></i> <!-- Graphique pour rapports -->
                        <div data-i18n="Analytics">Rapport Remboursement</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a wire:navigate href="<?php echo e(route('rapports.depot_retrait')); ?>" class="menu-link">
                        <i class="menu-icon tf-icons bx bx-bar-chart"></i> <!-- Graphique pour rapports -->
                        <div data-i18n="Analytics">Rapport Dépôt-Retrait</div>
                    </a>
                </li>
                
            </ul>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-role')): ?>
        <li class="menu-item <?php if(request()->routeIs('role.management','user.management')): ?> 
            active <?php endif; ?>" wire:ignore.self>
            <a class="menu-link menu-toggle">
            <i class="menu-icon tf-icons bx bx-group"></i>
            <div data-i18n="Misc">Rôles et Utilisateurs</div>
            </a>
            <ul class="menu-sub">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-role')): ?>
                    <!-- Gestion Utilisateurs -->
                    <li class="menu-item <?php if(request()->routeIs('role.management')): ?> active <?php endif; ?>">
                        <a wire:navigate href="<?php echo e(route('role.management')); ?>" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-group"></i> <!-- Users -->
                            <div data-i18n="Analytics">Gestion Rôles</div>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('afficher-utilisateur')): ?>
                    <!-- Gestion Utilisateurs -->
                    <li class="menu-item <?php if(request()->routeIs('user.management')): ?> active <?php endif; ?>">
                        <a wire:navigate href="<?php echo e(route('user.management')); ?>" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-group"></i> <!-- Users -->
                            <div data-i18n="Analytics">Gestion Utilisateurs</div>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

    </ul>
</aside>

<?php /**PATH C:\laragon\www\musomusaada\resources\views/layouts/partials/aside.blade.php ENDPATH**/ ?>
<div class="mt-0">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ajouter-carnet')): ?>
    <div class="card">
        <div class="card-header bg-primary text-white">Achat de Carte d'Adhésion</div>
        <div class="card-body">
            <form wire:submit.prevent="submit">
                <div class="row mt-3">

                    <div class="col-md-6 mb-3">
                        <div class="position-relative">
                            <label>Membre</label>
                            <div class="table-search-input">
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text" id="basic-addon-search31">
                                        <i class="icon-base bx bx-search"></i></span>
                                    <input type="search" wire:model.live="search" class="form-control" 
                                        placeholder="Rechercher un membre"
                                        autocomplete="off" aria-label="Rechercher un membre" 
                                        aria-describedby="basic-addon-search31">
                                </div>
                            </div>

                            <!--[if BLOCK]><![endif]--><?php if(!empty($results)): ?>
                                <ul class="list-group w-100" style="z-index: 1000;">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item list-group-item-action"
                                        wire:click="selectResult(<?php echo e($user['id']); ?>)">
                                    <?php echo e("{$user['code']} {$user['name']} {$user['postnom']}"); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </ul>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Code de la carte</label>
                        <input type="text" wire:model="code" class="form-control" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Devise</label>
                        <select wire:model="currency" class="form-control">
                            <option value="USD">USD</option>
                            <option value="CDF">CDF</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['card_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Prix de la carte</label>
                        <input type="number" step="0.01" wire:model="price" class="form-control" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['card_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>Montant quotidien à épargner</label>
                        <input type="number" step="0.01" wire:model="subscription_amount" class="form-control" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['card_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <button type="submit" class="btn btn-success">
                    <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Valider l'achat de carte</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- resources/views/livewire/card-history.blade.php -->
    <div class=" mt-4">
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between">
                <div>
                    <h5>Historique des Cartes d'Adhésion</h4>
                </div>
                                <!-- Barre de recherche -->
                <div>
                    <input type="text" wire:model.live="searchCard" class="form-control" placeholder="Rechercher une carte...">
                </div>
            </div>

            <div class="card-body">
                <!-- Tableau des cartes -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Membre</th>
                                <th>Prix de la carte</th>
                                <th>Montant quotidien</th>
                                <th>Devise</th>
                                <th>Date de début</th>
                                <th>Date de fin</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($card->code); ?></td>
                                    <td><?php echo e(optional($card->member)->code ?? 'N/A'); ?> <?php echo e(optional($card->member)->name ?? 'N/A'); ?>

                                        <?php echo e(optional($card->member)->postnom ?? 'N/A'); ?> <?php echo e(optional($card->member)->prenom ?? 'N/A'); ?>

                                    </td>
                                    <td><?php echo e(number_format($card->price, 2)); ?> <?php echo e($card->currency); ?></td>
                                    <td><?php echo e(number_format($card->subscription_amount, 2)); ?> <?php echo e($card->currency); ?></td>
                                    <td><?php echo e($card->currency); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($card->start_date)->format('d/m/Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($card->end_date)->format('d/m/Y')); ?></td>
                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($card->is_active): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Terminée</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7" class="text-center">Aucune carte trouvée.</td></tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        Affichage de <?php echo e($cards->firstItem()); ?> à <?php echo e($cards->lastItem()); ?>

                        sur <?php echo e($cards->total()); ?> cartes
                    </div>
                    <div>
                        <?php echo e($cards->links()); ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/purchase-membership-card.blade.php ENDPATH**/ ?>
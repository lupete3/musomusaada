<!-- Modal -->
<div class="modal fade" id="modalMembre" tabindex="-1" aria-labelledby="modalMembreLabel" aria-hidden="true"
    data-focus="false" wire:ignore.self>
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <form wire:submit.prevent="<?php echo e($editModal ? 'update' : 'submit'); ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMembreLabel"><?php echo e(__("Information de l'utilisateur")); ?>

                    </h5>
                    <button type="button" class="btn-close" aria-label="Close" wire:click='closeModal'></button>
                </div>

                <div class="modal-body">

                    <!-- Membres -->
                    <div class="row g-3">

                    <!-- Nom -->
                    <div class="col-md-4 mb-1">
                        <label for="name" class="form-label">Nom</label>
                        <input type="text" wire:model.defer="name" id="name" class="form-control" placeholder="Nom"
                            required autofocus />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Postnom -->
                    <div class="col-md-4 mb-1">
                        <label for="postnom" class="form-label">Postnom</label>
                        <input type="text" wire:model.defer="postnom" id="postnom" class="form-control"
                            placeholder="Postnom" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['postnom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Prenom -->
                    <div class="col-md-4 mb-1">
                        <label for="prenom" class="form-label">Prénom (optionnel)</label>
                        <input type="text" wire:model.defer="prenom" id="prenom" class="form-control"
                            placeholder="Prénom" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Date de naissance -->
                    <div class="col-md-4 mb-1">
                        <label for="date_naissance" class="form-label">Date de naissance</label>
                        <input type="date" wire:model.defer="date_naissance" id="date_naissance" class="form-control"
                            required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_naissance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Téléphone -->
                    <div class="col-md-4 mb-1">
                        <label for="telephone" class="form-label">Téléphone</label>
                        <input type="text" wire:model.defer="telephone" id="telephone" class="form-control"
                            placeholder="+243........" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Profession -->
                    <div class="col-md-4 mb-1">
                        <label for="profession" class="form-label">Profession</label>
                        <input type="text" wire:model.defer="profession" id="profession" class="form-control"
                            placeholder="Ex: Agriculteur" />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Email -->
                    <div class="col-md-8 mb-1">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" wire:model.defer="email" id="email" class="form-control"
                            placeholder="exemple@domaine.com" required />
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Status physique -->
                    <div class="col-md-4 mb-1">
                        <label for="adresse_physique" class="form-label">Status</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="status" wire:model.defer="status">
                            <label class="form-check-label" for="status">Actif</label>
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adresse_physique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Mot de passe (pour la mise à jour uniquement) -->
                    <!--[if BLOCK]><![endif]--><?php if($editModal): ?>
                        <div class="col-md-6 mb-1">
                            <label for="password" class="form-label">Nouveau mot de passe (optionnel)</label>
                            <input type="password" wire:model.defer="password" id="password" class="form-control"
                                placeholder="Laisser vide pour ne pas changer" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="col-md-6 mb-1">
                        <label for="password" class="form-label">Rôles</label>

                        <div class="form-check">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roles_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input class="form-check-input" type="checkbox" wire:model.defer="roles" value="<?php echo e($role->name); ?>" id="role_<?php echo e($role->id); ?>">
                                <label class="form-check-label" for="role_<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!-- Adresse physique -->
                    <div class="col-md-12 mb-1">
                        <label for="adresse_physique" class="form-label">Adresse physique</label>
                        <textarea wire:model.defer="adresse_physique" id="adresse_physique" class="form-control"
                            rows="3"></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adresse_physique'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </div>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        wire:click='closeModal'><?php echo e(__('Fermer')); ?></button>
                    <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                        <span wire:loading class="spinner-border spinner-border-sm me-2"
                            role="status"></span>

                        <?php echo e($editModal ? __('Mettre à jour') : __('Ajouter')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    window.addEventListener('openModal', event => {
        const modalId = '#' + event.detail.name;

        $(document).ready(function () {
            const selectElement = $(modalId).find('.select2');
            selectElement.select2({
                dropdownParent: $(modalId)
            });

            // Synchroniser avec Livewire
            selectElement.on('change', function (e) {
                const data = $(this).val();
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').set('user_id', data); // synchronise avec la propriété Livewire
            });
        });
    });
</script>


<!-- Table des adhésions (inchangée) -->
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/user/add-member.blade.php ENDPATH**/ ?>
<div class="card mt-4">
    <div class="card-header d-flex justify-between">
        <h5 class="card-title mb-0">Historique des Clôtures de Caisse</h5>
        <button wire:click="exportPdf" class="btn btn-primary btn-sm">
            <span wire:loading wire:target="exportPdf" class="spinner-border spinner-border-sm me-2" role="status"></span>
            Exporter PDF
        </button>
    </div>

    <div class="card-body">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Agent de</th>
                    <th>Date</th>
                    <th>Solde Théorique USD</th>
                    <th>Solde Théorique CDF</th>
                    <th>Solde Physique USD</th>
                    <th>Solde Physique CDF</th>
                    <th>Ecart USD</th>
                    <th>Ecart CDF</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $closings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $closing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($closing->user->name); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($closing->closing_date)->format('d/m/Y')); ?></td>
                        <td><?php echo e(number_format($closing->logical_usd, 2)); ?> $</td>
                        <td><?php echo e(number_format($closing->physical_cdf, 2)); ?> Fc</td>
                        <td><?php echo e(number_format($closing->logical_usd, 2)); ?> $</td>
                        <td><?php echo e(number_format($closing->physical_cdf, 2)); ?> Fc</td>
                        <td><?php echo e(number_format($closing->gap_usd, 2)); ?> $</td>
                        <td><?php echo e(number_format($closing->gap_cdf, 2)); ?> Fc</td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($closing->status == 'pending'): ?>
                                <span class="badge bg-warning">En attente</span>
                            <?php elseif($closing->status == 'validated'): ?>
                                <span class="badge bg-success">Validée</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Rejetée</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->role === 'admin' && $closing->status === 'pending'): ?>
                                <button wire:click="validateClosing(<?php echo e($closing->id); ?>)" class="btn btn-success btn-sm">Valider</button>

                                <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($closing->id); ?>">Rejeter</button>

                                
                                <div class="modal fade" id="rejectModal<?php echo e($closing->id); ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Motif du rejet</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <textarea wire:model.defer="rejection_reason" class="form-control" rows="3"></textarea>
                                            </div>
                                            <div class="modal-footer">
                                                <button wire:click="rejectClosing(<?php echo e($closing->id); ?>)" class="btn btn-danger" data-bs-dismiss="modal">Rejeter</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            

                            <!--[if BLOCK]><![endif]--><?php if($closing->status !== 'pending'): ?>
                                <a href="<?php echo e(route('cloture.print', $closing->id)); ?>"
                                    class="btn btn-primary btn-sm">
                                    <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>Imprimer</button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <div class="card-footer">
        <?php echo e($closings->links()); ?>

    </div>

    
            <!-- Modal Bootstrap -->
        <div wire:ignore.self class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Modifier la clôture</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">
                        <h6>Billetage USD</h6>
                        <div class="row mb-3">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $editBilletageUSD; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valeur => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2">
                                    <label class="form-label">$<?php echo e($valeur); ?></label>
                                    <input type="number" wire:model.defer="editBilletageUSD.<?php echo e($valeur); ?>" class="form-control" min="0">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <h6>Billetage CDF</h6>
                        <div class="row mb-3">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $editBilletageCDF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valeur => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2">
                                    <label class="form-label"><?php echo e($valeur); ?> Fc</label>
                                    <input type="number" wire:model.defer="editBilletageCDF.<?php echo e($valeur); ?>" class="form-control" min="0">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-3">
                            <label for="editNote" class="form-label">Note</label>
                            <textarea class="form-control" wire:model.defer="editNote" rows="3"></textarea>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button class="btn btn-primary" wire:click="updateCloture">Enregistrer</button>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/cash/cash-closing-history.blade.php ENDPATH**/ ?>
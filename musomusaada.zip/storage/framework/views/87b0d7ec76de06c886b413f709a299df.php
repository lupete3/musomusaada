<div class="mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">Clôture de caisse - Agent</h5>
        </div>

        <div class="card-body">
            
            <p><strong>Agent :</strong> <?php echo e(auth()->user()->name); ?> <?php echo e(auth()->user()->postnom ?? ''); ?></p>
            <p><strong>Date :</strong> <?php echo e(\Carbon\Carbon::parse($date)->format('d/m/Y')); ?></p>

            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="alert alert-success">
                        <h6>Solde logique</h6>
                        <p>USD : <?php echo e(number_format($logical_usd, 2)); ?> $</p>
                        <p>CDF : <?php echo e(number_format($logical_cdf, 2)); ?> Fc</p>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="alert alert-warning">
                        <h6>Solde physique</h6>
                        <p>USD : <?php echo e(number_format($physical_usd, 2)); ?> $</p>
                        <p>CDF : <?php echo e(number_format($physical_cdf, 2)); ?> Fc</p>
                    </div>
                </div>
            </div>

            
            <h6 class="mt-4">Billetage USD</h6>
            <div class="row mb-3">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $denominations_usd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denomination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 mb-2">
                        <label class="form-label">$<?php echo e($denomination); ?></label>
                        <input type="number" wire:model.lazy="billetages_usd.<?php echo e($denomination); ?>" class="form-control" min="0">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <h6 class="mt-4">Billetage CDF</h6>
            <div class="row mb-3">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $denominations_cdf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $denomination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 mb-2">
                        <label class="form-label"><?php echo e($denomination); ?> Fc</label>
                        <input type="number" wire:model.lazy="billetages_cdf.<?php echo e($denomination); ?>" class="form-control" min="0">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="alert alert-danger">
                        <h6>Écart USD</h6>
                        <p><?php echo e(number_format($gap_usd, 2)); ?> $</p>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="alert alert-danger">
                        <h6>Écart CDF</h6>
                        <p><?php echo e(number_format($gap_cdf, 2)); ?> Fc</p>
                    </div>
                </div>
            </div>

            
            <div class="text-end mt-3">
                <button wire:click="submitCloture" class="btn btn-success" wire:loading.attr="disabled">
                    <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                    <i class="bx bx-lock"></i> Clôturer la caisse
                </button>
            </div>
        </div>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cash.cash-closing-history', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3386133095-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/cash/cloture-caisse.blade.php ENDPATH**/ ?>
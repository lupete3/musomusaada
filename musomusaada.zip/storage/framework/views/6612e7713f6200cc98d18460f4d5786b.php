<!-- resources/views/livewire/credit-follow-up-report.blade.php -->
<div class="container mt-4">
    <h4>Rapport Global de crédits</h4>
    <!-- Récapitulatif -->
    <div class="row g-3 mt-2 mb-4">
        <div class="col-md-6 col-lg-3">
            <div class="card border-primary h-100">
                <div class="card-body">
                    <h6 class="card-title text-primary">Crédits Totals</h6>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $totals['totalByCurrency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text"><?php echo e($curr); ?> : <?php echo e(number_format($total, 2)); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="card border-success h-100">
                <div class="card-body">
                    <h6 class="card-title text-success">Remboursés</h6>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $totals['totalPaidByCurrency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text"><?php echo e($curr); ?> : <?php echo e(number_format($total, 2)); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="card border-danger h-100">
                <div class="card-body">
                    <h6 class="card-title text-danger">En cours</h6>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $totals['totalUnpaidByCurrency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text"><?php echo e($curr); ?> : <?php echo e(number_format($total, 2)); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-3">
            <div class="card border-warning h-100">
                <div class="card-body">
                    <h6 class="card-title text-warning">Pénalités</h6>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $totals['penaltyByCurrency']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="card-text"><?php echo e($curr); ?> : <?php echo e(number_format($total, 2)); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </div>

    <div class="table-wrapper">
        <div class="card has-table ">
            <div class="card-header bg-light d-flex justify-between">
                <div class="row g-3">
                    <div class="col-md-3">
                        <input type="text" wire:model.live="searchMember" class="form-control"
                            placeholder="Rechercher membre..." />
                    </div>

                    <div class="col-md-2">
                        <select wire:model.live="currency" class="form-select">
                            <option value="">Devise</option>
                            <option value="USD">USD</option>
                            <option value="CDF">CDF</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <select wire:model.live="status" class="form-select">
                            <option value="">Statut</option>
                            <option value="paid">Remboursé</option>
                            <option value="unpaid">En cours</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <input type="date" wire:model.live="startDate" class="form-control" />
                    </div>

                    <div class="col-md-2">
                        <input type="date" wire:model.live="endDate" class="form-control" />
                    </div>


                </div>
                <div class="col-md-2">
                    <button wire:click="exportToPdf" class="btn btn-primary " wire:loading.attr="disabled">
                        <span wire:loading class="spinner-border spinner-border-sm me-2" role="status"></span>
                        <i class="bx bx-download"></i> Télécharger PDF
                    </button>
                </div>
            </div>
            <div class="card-table table-responsive">
                <table class="table card-table table-vcenter table-striped table-hover">
                    <thead class="table-warning">
                        <tr>
                            <th>ID Crédit</th>
                            <th>Code Membre</th>
                            <th>Nom Membre</th>
                            <th>Date Crédit</th>
                            <th>Montant</th>
                            <th>Solde Restant</th>
                            <th>Pénalité</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($credit->id); ?></td>
                            <td><?php echo e($credit->user->code); ?></td>
                            <td><?php echo e($credit->user->name.' '.$credit->user->postnom.' '.$credit->user->prenom ?? ''); ?>

                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($credit->start_date)->format('d/m/Y')); ?></td>
                            <td><?php echo e(number_format($credit->amount, 2)); ?> <?php echo e($credit->currency); ?></td>
                            <td>
                                <!--[if BLOCK]><![endif]--><?php if($credit->amount - $credit->repayments->where('is_paid', true)->sum('paid_amount') > 0): ?>
                                <?php echo e(number_format(
                                $credit->amount - $credit->repayments->where('is_paid', true)->sum('paid_amount'), 2
                                )); ?> <?php echo e($credit->currency); ?>

                                <?php else: ?>
                                +<?php echo e(number_format(
                                $credit->repayments->where('is_paid', true)->sum('paid_amount') - $credit->amount, 2
                                )); ?> <?php echo e($credit->currency); ?>

                                    
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                
                            </td>
                            <td>
                                <?php echo e(number_format(
                                $credit->repayments->sum('penalty'), 2
                                )); ?> <?php echo e($credit->currency); ?>

                            </td>
                            <td>
                                <!--[if BLOCK]><![endif]--><?php if($credit->is_paid): ?>
                                <span class="badge bg-success">Remboursé</span>
                                <?php else: ?>
                                <span class="badge bg-warning">En cours</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Aucun crédit trouvé.</td>
                        </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            <div class="card-footer d-flex justify-content-between align-items-center">
                <div>
                    Affichage de <?php echo e($credits->firstItem()); ?> à <?php echo e($credits->lastItem()); ?> sur <?php echo e($credits->total()); ?>

                </div>
                <div>
                    <?php echo e($credits->links()); ?>

                </div>
            </div>
        </div>
        <!-- Récapitulatif -->

    </div>
</div>
<?php /**PATH C:\laragon\www\musomusaada\resources\views/livewire/credit/credit-follow-up-report.blade.php ENDPATH**/ ?>
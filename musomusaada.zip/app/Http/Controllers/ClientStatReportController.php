<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClientStatReportController extends Controller
{
    public function rapportClient()
    {
        return view('rapports.clients');
    }
    public function rapportCarnets()
    {
        return view('rapports.carnets');
    }

    
}

<?php

namespace App\Livewire\Recouvreur;

use Livewire\Component;

class RecouvreurDashboard extends Component
{
    public function render()
    {
        return view('livewire.recouvreur.recouvreur-dashboard');
    }
}

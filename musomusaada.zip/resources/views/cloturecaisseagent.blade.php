@extends('layouts.backend')

@section('title', 'Clôture Caisse Agent')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:cash.cloture-caisse />

</div>


@endsection

@extends('layouts.backend')

@section('title', 'Depot cartes membres')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:make-daily-contribution />

</div>


@endsection

@extends('layouts.backend')

@section('title', 'Achay des cartes des membres')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:withdraw-from-card />

</div>


@endsection

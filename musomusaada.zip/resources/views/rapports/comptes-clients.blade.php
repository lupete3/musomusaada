@extends('layouts.backend')

@section('title', 'Rapports Clients')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:repports.rapport-compte-clients />

</div>

@endsection

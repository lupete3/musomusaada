@extends('layouts.backend')

@section('title', 'Rapports Transactions')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:repports.transaction-report />

</div>

@endsection

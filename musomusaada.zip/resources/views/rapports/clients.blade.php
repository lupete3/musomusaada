@extends('layouts.backend')

@section('title', 'Rapports Clients')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:repports.client-stat-report-component />

</div>

@endsection

@extends('layouts.backend')

@section('title', 'Caisse Centrale')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:admin.manage-cash-register lazy/>

</div>


@endsection

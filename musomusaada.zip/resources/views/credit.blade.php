@extends('layouts.backend')

@section('title', 'Octroit Crédit')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:credit.grant-credit lazy />

</div>


@endsection

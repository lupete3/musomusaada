@extends('layouts.backend')

@section('title', 'Balance des crédits')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:credit.credit-overview-report />

</div>


@endsection

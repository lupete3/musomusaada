@extends('layouts.backend')

@section('title', 'Simulation Credit')

@section('content')

    <livewire:loan-simulation />

@endsection

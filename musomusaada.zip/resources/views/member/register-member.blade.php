@extends('layouts.backend')

@section('title', 'Enregistrer un membre')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:members.register-member lazy/>

</div>


@endsection

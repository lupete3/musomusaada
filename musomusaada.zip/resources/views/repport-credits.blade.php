@extends('layouts.backend')

@section('title', 'Tableaude bord')

@section('content')

    <livewire:credit.credit-follow-up-report />

@endsection

@extends('layouts.backend')

@section('title', 'Transfert Compte')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:admin.fund-transfer-component />

</div>


@endsection

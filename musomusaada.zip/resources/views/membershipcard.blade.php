@extends('layouts.backend')

@section('title', 'Achat des cartes des membres')

@section('content')

<div class="container-xxl flex-grow-1 container-p-y">

    <livewire:purchase-membership-card />

</div>


@endsection

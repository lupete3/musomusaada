import './bootstrap';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.css';
import Chart from 'chart.js/auto';

import ApexCharts from 'apexcharts';
window.ApexCharts = ApexCharts;

window.Swal = Swal;

window.Chart = Chart;
